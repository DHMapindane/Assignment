package controller;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.inject.Named;

import model.Employee;
import service.EmployeeEJB;
import entities.EmployeeEntity;

@ManagedBean(name = "employeecontroller" ,eager = true)
@SessionScoped
public class EmployeeController{
 
    @EJB
    private EmployeeEJB employeeEJB;
    
  //from form
  	@ManagedProperty(value="#{employee}")
    private Employee employee;
  	
    private List<Employee> employeeList = new ArrayList<>();
 
   public List<Employee> getEmployeeList() {
	   
	    List<EmployeeEntity> entityListValues = employeeEJB.findEmployees();
		employeeList.clear();
	    for (EmployeeEntity employeeEntityData : entityListValues) 
    	{
	    	System.out.println("============================");
    		employee = new Employee();
    		employee.setName(employeeEntityData.getName());
    		employee.setSurName(employeeEntityData.getSurName());
    		employee.setDateOfBirth(employeeEntityData.getDateOfBirth());
    		employeeList.add(employee);
    	}
        return employeeList;
    }
 
   public String viewEmployee(){
        return "employeelist.xhtml";
    }
   
    public String addNewEmployee() {
         employeeEJB.addNew(employee.getEntity());
              return "employeelist.xhtml";
    }

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
    
    
}